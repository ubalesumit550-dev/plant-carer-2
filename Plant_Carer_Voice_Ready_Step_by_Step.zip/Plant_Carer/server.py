import os, io, base64
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image
import httpx

BASE = os.path.dirname(os.path.abspath(__file__))
app = FastAPI(title="Plant Carer")
app.mount("/assets", StaticFiles(directory=BASE), name="assets")

SAFE_ADVICE = {
    "en": ["Remove badly affected leaves and dispose of them away from the field. Clean tools between plants.", "Avoid overhead watering and improve airflow where possible.", "Do not choose pesticides from a photo alone. Ask your local KVK/agriculture officer and follow registered product labels."],
    "mr": ["जास्त बाधित पाने काढून शेतापासून दूर नष्ट करा. रोपांदरम्यान अवजारे स्वच्छ करा.", "वरून पाणी मारणे टाळा आणि रोपांमध्ये हवा खेळती ठेवा.", "फक्त फोटोवरून औषध ठरवू नका. स्थानिक KVK किंवा कृषी अधिकाऱ्यांचा सल्ला घ्या."],
    "hi": ["बहुत प्रभावित पत्तों को हटाकर खेत से दूर नष्ट करें। औज़ार साफ़ करें।", "ऊपर से पानी देने से बचें और पौधों के बीच हवा का आवागमन रखें।", "केवल फोटो देखकर दवा न चुनें। स्थानीय KVK या कृषि अधिकारी से सलाह लें।"]
}

@app.get("/")
def home():
    return FileResponse(os.path.join(BASE, "index.html"))

@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(os.path.join(BASE, "manifest.webmanifest"), media_type="application/manifest+json")

@app.get("/sw.js")
def service_worker():
    return FileResponse(os.path.join(BASE, "sw.js"), media_type="application/javascript")

@app.post("/api/diagnose")
async def diagnose(image: UploadFile = File(...), crop: str = Form("unknown"), language: str = Form("en")):
    if image.content_type not in ("image/jpeg", "image/png", "image/webp"):
        raise HTTPException(400, "Upload a JPG, PNG or WEBP photo.")
    raw = await image.read()
    if len(raw) > 8 * 1024 * 1024:
        raise HTTPException(413, "Photo must be smaller than 8 MB.")
    try:
        im = Image.open(io.BytesIO(raw))
        im.verify()
    except Exception:
        raise HTTPException(400, "The uploaded file is not a valid image.")

    lang = language if language in SAFE_ADVICE else "en"
    api_key = os.getenv("PLANT_ID_API_KEY", "").strip()
    if not api_key:
        demo_text = {
            "en": ("AI service is not configured", "Photo received, but real AI diagnosis is not active."),
            "mr": ("AI सेवा जोडलेली नाही", "फोटो मिळाला आहे; पण खरे AI निदान सुरू नाही."),
            "hi": ("AI सेवा जुड़ी नहीं है", "तस्वीर मिली है, लेकिन असली AI जाँच चालू नहीं है।")
        }
        return {
            "disease": demo_text[lang][0],
            "confidence": "Demo mode — not a diagnosis",
            "description": demo_text[lang][1],
            "treatment": SAFE_ADVICE[lang]
        }

    encoded = base64.b64encode(raw).decode("ascii")
    payload = {
        "images": [f"data:{image.content_type};base64,{encoded}"],
        "health": "all",
        "similar_images": False
    }
    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.post(
            "https://api.plant.id/v3/health_assessment",
            headers={"Api-Key": api_key},
            json=payload
        )
    if response.status_code >= 400:
        raise HTTPException(502, "The AI provider returned an error. Try again later.")
    result = response.json().get("result", {})
    health = result.get("is_healthy", {})
    if health.get("binary") is True:
        return {
            "disease": "Likely healthy plant",
            "confidence": f"AI confidence: {health.get('probability', 0):.0%}",
            "description": "No clear disease symptom was detected in this image.",
            "treatment": ["Continue regular crop monitoring.", "Use balanced irrigation and crop nutrition based on local advice."]
        }
    suggestions = result.get("disease", {}).get("suggestions", [])
    if not suggestions:
        return {
            "disease": "No reliable match",
            "confidence": "Low confidence",
            "description": "The photo did not produce a reliable disease match. Retake a clear photo and seek local advice.",
            "treatment": SAFE_ADVICE[lang]
        }
    top = suggestions[0]
    return {
        "disease": top.get("name", "Possible disease"),
        "confidence": f"AI confidence: {top.get('probability', 0):.0%}",
        "description": "Possible image match. Confirm with a local expert before treatment.",
        "treatment": SAFE_ADVICE[lang]
    }
