PLANT CARER — STEP-BY-STEP SETUP

WHAT YOU HAVE
This ZIP contains the Plant Carer website source. It includes English/Marathi/Hindi screens, five crop choices (pomegranate, onion, tomato, chilli, cotton), photo upload/camera, voice read-aloud buttons, and a server endpoint ready for an AI diagnosis provider.
Important: without a provider API key, the app will say DEMO MODE and will not pretend to diagnose a disease.

A. RUN IT ON A WINDOWS COMPUTER
1. On a Windows laptop/desktop, open https://www.python.org/downloads/
2. Download Python 3.11 or newer. During installation, tick "Add Python to PATH", then install.
3. Download the Plant_Carer ZIP and extract it (right-click > Extract All).
4. Open the extracted Plant_Carer folder.
5. Double-click run_windows.bat. The first run needs internet to install Python packages. Wait until the terminal shows a local server address.
6. Open Google Chrome on that same computer and enter http://127.0.0.1:8000
7. Select language and crop. Press Take/Choose Photo, select a leaf photo, then press Check plant.
8. When a result appears, press "Listen to advice". Your browser/device must have Marathi or Hindi text-to-speech voice installed/enabled. The app asks the browser to use mr-IN or hi-IN; available voices depend on the device.

B. OPEN IT ON YOUR ANDROID PHONE FOR A TEST
1. Computer and phone must be connected to the same Wi-Fi.
2. Find the computer's local IP address (Windows: open Command Prompt and type ipconfig; look for IPv4 Address).
3. In run_windows.bat, the server is currently bound to 127.0.0.1, which only allows same-computer testing. For phone testing, stop it with Ctrl+C and run this command in the Plant_Carer folder after dependencies install:
   python -m uvicorn server:app --host 0.0.0.0 --port 8000
4. On the phone, open Chrome and visit http://COMPUTER-IP:8000 (replace COMPUTER-IP with the IPv4 address).
5. This is local-network testing only. Camera/PWA install features generally require HTTPS or localhost; for reliable install, publish the website on an HTTPS host.

C. INSTALL IT LIKE AN APP ON ANDROID
1. Publish the website and Python backend to a hosting service that supports Python/FastAPI and HTTPS.
2. Set PLANT_ID_API_KEY as a private server environment variable on the host. Never paste the secret key into app.js or share it in the APK.
3. Open the HTTPS website in Android Chrome.
4. Tap the three-dot menu > Install app (or Add to Home screen).
5. Plant Carer will appear on the phone home screen. This is an installable web app (PWA), not a separately signed APK.

D. TURN ON REAL AI PHOTO DIAGNOSIS
1. Create an account with a plant image diagnosis provider such as Plant.id and check current plans, pricing, quotas, privacy terms and crop coverage.
2. Get an API key.
3. On the server/hosting dashboard, add an environment variable named PLANT_ID_API_KEY and paste the key as its value.
4. Restart/redeploy the server.
5. Upload known, correctly labelled crop photos and verify results with a local agriculture expert before farmer release.
Do not put the API key in the browser or Android package.

E. ANDROID APK (SEPARATE APK FILE)
This source package does not contain a compiled APK. A signed APK requires Android Studio/Android SDK and a wrapper build (for example, Capacitor), plus the live HTTPS backend URL and release signing. The easiest first release is the installable Android PWA described in section C. After the website is deployed and tested, an Android developer can package it as an APK.

F. IMPORTANT FARMER SAFETY
AI photo screening can be wrong, especially with poor lighting, mixed symptoms, pests or nutrient deficiency. Do not spray pesticides only from an AI result. Confirm with your local Krishi Vigyan Kendra (KVK) or agriculture officer and follow the current registered product label. Hosting and AI usage may cost money even if farmers use the app free of charge.
